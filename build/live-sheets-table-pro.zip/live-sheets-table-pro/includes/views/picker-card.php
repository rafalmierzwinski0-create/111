<?php
/**
 * The sheet drawn as a control: click what you want gone.
 *
 * @package LiveSheetsTablePro
 *
 * @var array<int,string>            $headers Sheet headings.
 * @var array<int,array<int,string>> $rows    Every row of the sheet.
 * @var array<int,array<int,string>> $shown   The rows offered for clicking.
 * @var array<int,array>             $columns Column settings.
 * @var array<int,array>             $hidden  Stored choices about rows.
 * @var array<int,bool>              $dropped Positions currently taken out.
 * @var int                          $offset  Lines of the sheet above the first row.
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="lstab-card lstabp-picker-card">
	<h2 class="lstab-card-title"><?php esc_html_e( 'Hide columns and rows', 'live-sheets-table-pro' ); ?></h2>
	<p class="lstab-help">
		<?php esc_html_e( 'Click a heading to hide that column, or a line number to hide that row. Click again to bring it back. Nothing is written to Google.', 'live-sheets-table-pro' ); ?>
	</p>

	<?php
	/*
	 * Said before anything is clicked, not after something has gone wrong.
	 * Someone who knows in advance that reordering their sheet undoes these
	 * choices can plan around it; someone who learns it from a notice a week
	 * later has already published the page.
	 */
	?>
	<div class="notice notice-info inline lstabp-picker-note">
		<p>
			<strong><?php esc_html_e( 'Moving a column or row in Google will show it again', 'live-sheets-table-pro' ); ?></strong>
		</p>
		<p>
			<?php esc_html_e( 'A hidden column is matched by its heading, a hidden row by its line number. Reordering columns, renaming a heading or inserting a row above breaks that match.', 'live-sheets-table-pro' ); ?>
		</p>
		<p>
			<?php esc_html_e( 'When a match breaks, the column or row is shown again rather than the wrong one being hidden. A notice in the dashboard names the table, and you can hide it again here.', 'live-sheets-table-pro' ); ?>
		</p>
	</div>

	<p class="lstabp-picker-legend">
		<span class="lstabp-legend-chip"><span class="lstabp-legend-mark" aria-hidden="true">×</span><?php esc_html_e( 'Click a heading or a line number to hide it', 'live-sheets-table-pro' ); ?></span>
		<span class="lstabp-legend-chip"><span class="lstabp-legend-mark lstabp-legend-mark--back" aria-hidden="true">↺</span><?php esc_html_e( 'Click it again to put it back', 'live-sheets-table-pro' ); ?></span>
		<span class="lstabp-legend-chip"><span class="lstabp-legend-mark lstabp-legend-mark--detail" aria-hidden="true"></span><?php esc_html_e( 'Click the arrow to move a column under the row instead', 'live-sheets-table-pro' ); ?></span>
	</p>

	<?php
	/*
	 * The first data row is numbered 2, because line 1 is the headings. Nobody
	 * counting rows in the table in front of them arrives at that on their own,
	 * and the numbers are the whole way a hidden row is matched later.
	 */
	?>
	<p class="lstab-help lstabp-picker-lines">
		<?php esc_html_e( 'The numbers down the left are the line numbers in your sheet, so line 1 is the headings.', 'live-sheets-table-pro' ); ?>
	</p>

	<div class="lstabp-picker-scroll">
		<table class="lstabp-picker" id="lstabp-picker">
			<thead>
				<tr>
					<th class="lstabp-picker-corner" scope="col">
						<span class="screen-reader-text"><?php esc_html_e( 'Line', 'live-sheets-table-pro' ); ?></span>
					</th>
					<?php foreach ( $headers as $lstabp_i => $lstabp_head ) : ?>
						<?php
						$lstabp_col_hidden = ! empty( $columns[ $lstabp_i ]['hidden'] );
						$lstabp_col_detail = ! empty( $columns[ $lstabp_i ]['detail'] );
						$lstabp_col_name   = '' === trim( (string) $lstabp_head )
							/* translators: %s: column letter, as Google labels it. */
							? sprintf( __( 'Column %s', 'live-sheets-table-pro' ), LSTAB_Columns::letter( $lstabp_i ) )
							: (string) $lstabp_head;
						?>
						<th scope="col" class="lstabp-picker-col<?php echo $lstabp_col_hidden ? ' is-hidden' : ''; ?><?php echo $lstabp_col_detail ? ' is-detail' : ''; ?>">
							<button type="button"
								class="lstabp-picker-toggle"
								data-lstabp-column="<?php echo esc_attr( (string) $lstabp_i ); ?>"
								aria-pressed="<?php echo $lstabp_col_hidden ? 'true' : 'false'; ?>">
								<span class="lstabp-picker-name"><?php echo esc_html( $lstabp_col_name ); ?></span>
								<span class="lstabp-picker-mark" aria-hidden="true"></span>
							</button>
							<?php
							/*
							 * A second, separate mark rather than a click that
							 * cycles through three states: cycling makes the
							 * first click ambiguous and the third a guess, and
							 * the click that takes a column out is a gesture
							 * people already know from this screen.
							 */
							?>
							<button type="button"
								class="lstabp-picker-detail"
								data-lstabp-detail="<?php echo esc_attr( (string) $lstabp_i ); ?>"
								aria-pressed="<?php echo $lstabp_col_detail ? 'true' : 'false'; ?>"
								<?php disabled( $lstabp_col_hidden ); ?>
								title="<?php echo esc_attr( sprintf( /* translators: %s: column name. */ __( 'Move “%s” under the row, behind an arrow', 'live-sheets-table-pro' ), $lstabp_col_name ) ); ?>">
								<span class="screen-reader-text">
									<?php
									printf(
										/* translators: %s: column name. */
										esc_html__( 'Move “%s” under the row, behind an arrow', 'live-sheets-table-pro' ),
										esc_html( $lstabp_col_name )
									);
									?>
								</span>
								<span class="lstabp-picker-chevron" aria-hidden="true"></span>
							</button>
						</th>
					<?php endforeach; ?>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $shown as $lstabp_r => $lstabp_row ) : ?>
					<?php
					$lstabp_off  = isset( $dropped[ $lstabp_r ] );
					$lstabp_line = $offset + $lstabp_r + 1;
					?>
					<tr class="lstabp-picker-row<?php echo $lstabp_off ? ' is-hidden' : ''; ?>"
						data-lstabp-index="<?php echo esc_attr( (string) $lstabp_r ); ?>"
						data-lstabp-name="<?php echo esc_attr( LSTAB_Hidden_Rows::key_for( $lstabp_row ) ); ?>"
						data-lstabp-sig="<?php echo esc_attr( LSTAB_Hidden_Rows::signature( $lstabp_row ) ); ?>"
						data-lstabp-label="<?php echo esc_attr( LSTAB_Hidden_Rows::describe( $lstabp_row ) ); ?>"
						data-lstabp-line="<?php echo esc_attr( (string) $lstabp_line ); ?>">
						<th scope="row" class="lstabp-picker-handle">
							<button type="button"
								class="lstabp-picker-toggle"
								data-lstabp-row="<?php echo esc_attr( (string) $lstabp_r ); ?>"
								aria-pressed="<?php echo $lstabp_off ? 'true' : 'false'; ?>">
								<span class="lstabp-picker-number"><?php echo esc_html( (string) $lstabp_line ); ?></span>
								<span class="lstabp-picker-mark" aria-hidden="true"></span>
							</button>
						</th>
						<?php foreach ( $headers as $lstabp_i => $lstabp_unused ) : ?>
							<?php
							$lstabp_col_hidden = ! empty( $columns[ $lstabp_i ]['hidden'] );
							$lstabp_col_detail = ! empty( $columns[ $lstabp_i ]['detail'] );
							?>
							<td class="lstabp-picker-cell<?php echo $lstabp_col_hidden ? ' is-hidden' : ''; ?><?php echo $lstabp_col_detail ? ' is-detail' : ''; ?>"
								data-lstabp-column="<?php echo esc_attr( (string) $lstabp_i ); ?>">
								<?php echo esc_html( isset( $lstabp_row[ $lstabp_i ] ) ? $lstabp_row[ $lstabp_i ] : '' ); ?>
							</td>
						<?php endforeach; ?>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<?php if ( count( $rows ) > LSTABP_Picker::MAX_ROWS ) : ?>
		<p class="lstab-help">
			<?php
			printf(
				/* translators: 1: rows shown here, 2: rows in the sheet. */
				esc_html__( 'Showing the first %1$d of %2$d rows. Beyond that, use the filter above rather than picking rows one at a time.', 'live-sheets-table-pro' ),
				(int) LSTABP_Picker::MAX_ROWS,
				count( $rows )
			);
			?>
		</p>
	<?php endif; ?>

	<div class="lstabp-picker-paging" id="lstabp-picker-paging" hidden>
		<span class="lstabp-page-group" data-lstabp-page-for="rows" hidden>
			<button type="button" class="lstab-mini" data-lstabp-step="rows:-1">&larr;</button>
			<span class="lstabp-page-label" data-lstabp-page-label="rows"></span>
			<button type="button" class="lstab-mini" data-lstabp-step="rows:1">&rarr;</button>
		</span>
		<span class="lstabp-page-group" data-lstabp-page-for="cols" hidden>
			<button type="button" class="lstab-mini" data-lstabp-step="cols:-1">&larr;</button>
			<span class="lstabp-page-label" data-lstabp-page-label="cols"></span>
			<button type="button" class="lstab-mini" data-lstabp-step="cols:1">&rarr;</button>
		</span>
	</div>

	<div class="lstabp-picker-summary">
		<p class="lstabp-picker-empty"<?php echo $hidden ? ' hidden' : ''; ?>>
			<?php esc_html_e( 'No rows hidden yet.', 'live-sheets-table-pro' ); ?>
		</p>
		<ul class="lstabp-chips" id="lstabp-hidden-rows-chips"></ul>
	</div>

	<?php
	/*
	 * Says the picker was on the screen, so that a save made anywhere else
	 * leaves the stored list alone rather than reading "no fields submitted"
	 * as "nothing is hidden".
	 */
	?>
	<input type="hidden" name="_lstab_hidden_rows_present" value="1">

	<div id="lstabp-hidden-rows-fields" hidden>
		<?php foreach ( $hidden as $lstabp_index => $lstabp_entry ) : ?>
			<?php $lstabp_live = LSTAB_Hidden_Rows::still_there( $lstabp_entry, $rows ); ?>
			<?php foreach ( array( 'index', 'name', 'sig', 'label' ) as $lstabp_part ) : ?>
				<input type="hidden"
					name="hidden_rows[<?php echo esc_attr( (string) $lstabp_index ); ?>][<?php echo esc_attr( $lstabp_part ); ?>]"
					value="<?php echo esc_attr( (string) $lstabp_entry[ $lstabp_part ] ); ?>"
					<?php if ( 'index' === $lstabp_part ) : ?>
						data-lstabp-present="<?php echo $lstabp_live ? '1' : '0'; ?>"
						data-lstabp-name="<?php echo esc_attr( $lstabp_entry['name'] ); ?>"
						data-lstabp-sig="<?php echo esc_attr( $lstabp_entry['sig'] ); ?>"
						data-lstabp-label="<?php echo esc_attr( $lstabp_entry['label'] ); ?>"
						data-lstabp-line="<?php echo esc_attr( (string) ( $offset + (int) $lstabp_entry['index'] + 1 ) ); ?>"
					<?php endif; ?>
				>
			<?php endforeach; ?>
		<?php endforeach; ?>
	</div>
</div>
