<?php

defined( 'ABSPATH' ) || exit;

$lstabp_waiting = ! $headers;
$lstabp_total   = count( $rows );
?>
<div class="lstab-card lstabp-facets-card">
	<h2 class="lstab-card-title"><?php esc_html_e( 'Let visitors narrow the table', 'live-sheets-table-pro' ); ?></h2>
	<p class="lstab-help">
		<?php esc_html_e( 'Tick a column and a menu of its values appears above the table. A visitor opens the menu, picks a value, and the table keeps only the rows that match. Picking several values in one menu shows rows with any of them; using several menus narrows the table further.', 'live-sheets-table-pro' ); ?>
	</p>

	<?php
	$lstabp_demo = array();

	foreach ( $headers as $lstabp_demo_index => $lstabp_demo_head ) {
		if ( count( $lstabp_demo ) >= 2 ) {
			break;
		}

		$lstabp_demo_tally = LSTABP_Facets::tally( $rows, $lstabp_demo_index );
		$lstabp_demo_kinds = count( $lstabp_demo_tally );
		$lstabp_demo_each  = $lstabp_demo_kinds > 0 ? array_sum( $lstabp_demo_tally ) / $lstabp_demo_kinds : 0;

		if ( $lstabp_demo_kinds < 2 || $lstabp_demo_each < 2 || $lstabp_demo_kinds > LSTABP_Facets::LONG_MENU ) {
			continue;
		}

		arsort( $lstabp_demo_tally );

		$lstabp_demo[] = array(
			'heading' => (string) $lstabp_demo_head,
			'value'   => (string) key( $lstabp_demo_tally ),
			'rows'    => (int) current( $lstabp_demo_tally ),
		);
	}

	if ( ! $lstabp_demo ) {
		$lstabp_demo[] = array(
			'heading' => __( 'Availability', 'live-sheets-table-pro' ),
			'value'   => __( 'In stock', 'live-sheets-table-pro' ),
			'rows'    => 0,
		);
	}
	?>
	<div class="lstabp-facets-demo">
		<span class="lstabp-facets-demo-caption">
			<?php esc_html_e( 'This is what a visitor sees above the table:', 'live-sheets-table-pro' ); ?>
		</span>

		<span class="lstabp-facets-demo-bar" aria-hidden="true">
			<span class="lstabp-facets-demo-label"><?php esc_html_e( 'Show only:', 'live-sheets-table-pro' ); ?></span>

			<?php foreach ( $lstabp_demo as $lstabp_demo_at => $lstabp_demo_facet ) : ?>
				<span class="lstabp-facets-demo-pick<?php echo 0 === $lstabp_demo_at ? ' is-on' : ''; ?>">
					<b><?php echo esc_html( $lstabp_demo_facet['heading'] ); ?>:</b>
					<?php
					echo esc_html(
						0 === $lstabp_demo_at
							? $lstabp_demo_facet['value']
							: __( 'any', 'live-sheets-table-pro' )
					);
					?>
					<span class="lstabp-facets-demo-arrow">▾</span>
				</span>
			<?php endforeach; ?>

			<?php if ( $lstabp_demo[0]['rows'] ) : ?>
				<span class="lstabp-facets-demo-clear">
					<?php
					printf(
						/* translators: %s: how many rows the table holds in all. */
						esc_html__( 'Clear filters — show all %s', 'live-sheets-table-pro' ),
						esc_html( number_format_i18n( $lstabp_total ) )
					);
					?>
				</span>
			<?php endif; ?>
		</span>

		<?php if ( $lstabp_demo[0]['rows'] ) : ?>
			<span class="lstabp-facets-demo-rows">
				<?php
				printf(
					/* translators: 1: rows left after the filter, 2: rows in all. */
					esc_html__( 'The table then shows %1$s of its %2$s rows.', 'live-sheets-table-pro' ),
					esc_html( number_format_i18n( $lstabp_demo[0]['rows'] ) ),
					esc_html( number_format_i18n( $lstabp_total ) )
				);
				?>
			</span>
		<?php endif; ?>
	</div>

	<p class="lstab-help">
		<?php esc_html_e( 'The menus work together with the search box. On a table split into pages, they look through all the rows, not just the page on screen.', 'live-sheets-table-pro' ); ?>
	</p>

	<p class="lstab-help">
		<?php esc_html_e( 'The numbers below come from the sheet as it was last read.', 'live-sheets-table-pro' ); ?>
	</p>

	<?php if ( $lstabp_waiting ) : ?>
		<p class="lstab-columns-waiting">
			<?php
			echo esc_html(
				$is_edit
					? __( 'The sheet has not been read yet, so there are no columns to choose from.', 'live-sheets-table-pro' )
					: __( 'Paste the sheet’s link and choose “Load preview” first. The columns then appear here.', 'live-sheets-table-pro' )
			);
			?>
		</p>
	<?php else : ?>
		<input type="hidden" name="_lstabp_facets_present" value="1">

		<ul class="lstabp-facet-picks" data-lstabp-fold="10">
			<?php foreach ( $headers as $lstabp_index => $lstabp_heading ) : ?>
				<?php
				$lstabp_tally  = LSTABP_Facets::tally( $rows, $lstabp_index );
				$lstabp_kinds  = count( $lstabp_tally );
				$lstabp_filled = array_sum( $lstabp_tally );
				$lstabp_on     = in_array( (string) $lstabp_heading, $chosen, true );

				$lstabp_each  = $lstabp_kinds > 0 ? $lstabp_filled / $lstabp_kinds : 0;
				$lstabp_suits = $lstabp_kinds >= 2 && $lstabp_each >= 2;
				$lstabp_long  = $lstabp_kinds > LSTABP_Facets::LONG_MENU;

				$lstabp_top = implode(
					', ',
					array_map(
						static function ( $lstabp_value, $lstabp_count ) {
							return $lstabp_value . ' (' . number_format_i18n( $lstabp_count ) . ')';
						},
						array_slice( array_keys( $lstabp_tally ), 0, 3 ),
						array_slice( array_values( $lstabp_tally ), 0, 3 )
					)
				) . ( $lstabp_kinds > 3 ? ' …' : '' );

				if ( 0 === $lstabp_kinds ) {
					$lstabp_says = __( 'This column is empty.', 'live-sheets-table-pro' );
				} elseif ( 1 === $lstabp_kinds ) {
					$lstabp_says = __( 'Every row holds the same value, so a filter here would narrow nothing.', 'live-sheets-table-pro' );
				} elseif ( $lstabp_kinds === $lstabp_filled ) {
					$lstabp_says = __( 'Every row is different, so each choice would leave one row. A search box does this better.', 'live-sheets-table-pro' );
				} elseif ( ! $lstabp_suits ) {
					$lstabp_says = sprintf(
						/* translators: 1: how many different values, 2: how many rows hold one. */
						__( '%1$s different values across %2$s rows, close to one per row. A search box suits this column better.', 'live-sheets-table-pro' ),
						number_format_i18n( $lstabp_kinds ),
						number_format_i18n( $lstabp_filled )
					);
				} elseif ( $lstabp_long ) {
					$lstabp_says = sprintf(
						/* translators: 1: how many different values, 2: rows behind each one on average, 3: the commonest few, already counted. */
						__( '%1$s different values, about %2$s rows each. A useful filter, but a long list, so its menu gets a box to type in. Most common: %3$s', 'live-sheets-table-pro' ),
						number_format_i18n( $lstabp_kinds ),
						number_format_i18n( (int) round( $lstabp_each ) ),
						$lstabp_top
					);
				} else {
					$lstabp_says = sprintf(
						/* translators: 1: how many different values, 2: the commonest few, already counted. */
						__( '%1$s different values: %2$s', 'live-sheets-table-pro' ),
						number_format_i18n( $lstabp_kinds ),
						$lstabp_top
					);
				}
				?>
				<li class="lstabp-facet-pick<?php echo $lstabp_suits ? ' is-suited' : ''; ?>">
					<label>
						<input type="checkbox"
							name="lstabp_facets[]"
							value="<?php echo esc_attr( $lstabp_heading ); ?>"
							<?php checked( $lstabp_on ); ?>>
						<span class="lstabp-facet-name">
							<?php echo esc_html( $lstabp_heading ); ?>
							<?php if ( $lstabp_suits ) : ?>
								<span class="lstabp-facet-flag"><?php esc_html_e( 'Suits a filter', 'live-sheets-table-pro' ); ?></span>
							<?php endif; ?>
						</span>
						<span class="lstabp-facet-says"><?php echo esc_html( $lstabp_says ); ?></span>
					</label>
				</li>
			<?php endforeach; ?>
		</ul>

	<?php endif; ?>
</div>
