( function () {
	'use strict';

	var picker = document.getElementById( 'lstab-picker' );
	if ( ! picker ) {
		return;
	}

	var settings = window.lstabPicker || {};
	var i18n = settings.i18n || {};

	( function paging() {
		var ROWS = 25;
		var COLS = 12;

		var bar = document.getElementById( 'lstab-picker-paging' );

		if ( ! bar ) {
			return;
		}

		var bodyRows = picker.querySelectorAll( 'tbody tr' );
		var headings = picker.querySelectorAll( 'thead th.lstab-picker-col' );
		var at = { rows: 0, cols: 0 };

		var pages = function ( total, per ) {
			return Math.max( 1, Math.ceil( total / per ) );
		};

		var rowPages = pages( bodyRows.length, ROWS );
		var colPages = pages( headings.length, COLS );

		if ( rowPages < 2 && colPages < 2 ) {
			return;
		}

		var label = function ( which, page, total, count ) {
			var text = ( 'rows' === which ? i18n.rowsPage : i18n.colsPage ) || '%1$s / %2$s';

			return text.replace( '%1$s', page + 1 ).replace( '%2$s', total ).replace( '%3$s', count );
		};

		var paint = function () {
			Array.prototype.forEach.call( bodyRows, function ( row, index ) {
				row.hidden = rowPages > 1 && Math.floor( index / ROWS ) !== at.rows;
			} );

			Array.prototype.forEach.call( headings, function ( head, index ) {
				var off = colPages > 1 && Math.floor( index / COLS ) !== at.cols;

				head.hidden = off;

				Array.prototype.forEach.call(
					picker.querySelectorAll( 'td[data-lstab-pick-column="' + index + '"]' ),
					function ( cell ) {
						cell.hidden = off;
					}
				);
			} );

			var groups = bar.querySelectorAll( '[data-lstab-pick-page-for]' );

			Array.prototype.forEach.call( groups, function ( group ) {
				var which = group.getAttribute( 'data-lstab-pick-page-for' );
				var total = 'rows' === which ? rowPages : colPages;
				var count = 'rows' === which ? bodyRows.length : headings.length;

				group.hidden = total < 2;
				group.querySelector( '[data-lstab-pick-page-label]' ).textContent =
					label( which, at[ which ], total, count );
			} );

			bar.hidden = false;
		};

		Array.prototype.forEach.call( bar.querySelectorAll( '[data-lstab-pick-step]' ), function ( button ) {
			button.addEventListener( 'click', function () {
				var parts = button.getAttribute( 'data-lstab-pick-step' ).split( ':' );
				var which = parts[ 0 ];
				var total = 'rows' === which ? rowPages : colPages;

				at[ which ] = ( at[ which ] + Number( parts[ 1 ] ) + total ) % total;
				paint();
			} );
		} );

		paint();
	}() );
	var fields = document.getElementById( 'lstab-hidden-rows-fields' );
	var chips = document.getElementById( 'lstab-hidden-rows-chips' );
	var empty = document.querySelector( '.lstab-picker-empty' );

	function strandedEntries() {
		var found = [];

		Array.prototype.forEach.call(
			fields.querySelectorAll( 'input[data-lstab-pick-present="0"]' ),
			function ( field ) {
				found.push( {
					index: field.value || '0',
					name: field.getAttribute( 'data-lstab-pick-name' ) || '',
					sig: field.getAttribute( 'data-lstab-pick-sig' ) || '',
					label: field.getAttribute( 'data-lstab-pick-label' ) || '',
					line: field.getAttribute( 'data-lstab-pick-line' ) || '',
					stranded: true
				} );
			}
		);

		return found;
	}

	var stranded = strandedEntries();

	function columnField( index ) {
		return document.querySelector(
			'input[type="hidden"][name="columns[' + index + '][hidden]"]'
		);
	}

	function detailField( index ) {
		return document.querySelector(
			'input[type="hidden"][name="columns[' + index + '][detail]"]'
		);
	}

	function paintState( index, hidden ) {
		var field = columnField( index );
		if ( ! field ) {
			return;
		}

		var cell = field.closest( '.lstab-column-state' );
		if ( ! cell ) {
			return;
		}

		var label = cell.querySelector( 'span' );
		if ( ! label ) {
			return;
		}

		var detail = detailField( index );
		var inDrawer = detail && '1' === detail.value;

		if ( hidden ) {
			label.className = 'lstab-state-hidden';
			label.textContent = i18n.hidden || 'Hidden';
		} else if ( inDrawer ) {
			label.className = 'lstab-state-detail';
			label.textContent = i18n.inDetails || 'In the details';
		} else {
			label.className = 'lstab-state-shown';
			label.textContent = i18n.shown || 'Shown';
		}
	}

	function paintDetail( index, detail ) {
		Array.prototype.forEach.call(
			picker.querySelectorAll( '[data-lstab-pick-column="' + index + '"]' ),
			function ( cell ) {
				cell.classList.toggle( 'is-detail', detail );

				var header = cell.closest( 'th' );
				if ( header ) {
					header.classList.toggle( 'is-detail', detail );
				}
			}
		);

		var button = picker.querySelector( 'button[data-lstab-pick-detail="' + index + '"]' );
		if ( button ) {
			button.setAttribute( 'aria-pressed', detail ? 'true' : 'false' );
			button.closest( 'th' ).classList.toggle( 'is-detail', detail );
		}
	}

	function paintColumn( index, hidden ) {
		Array.prototype.forEach.call(
			picker.querySelectorAll( '[data-lstab-pick-column="' + index + '"]' ),
			function ( cell ) {
				cell.classList.toggle( 'is-hidden', hidden );

				var header = cell.closest( 'th' );
				if ( header ) {
					header.classList.toggle( 'is-hidden', hidden );
				}
			}
		);

		var toggle = picker.querySelector( 'button[data-lstab-pick-column="' + index + '"]' );
		if ( toggle ) {
			toggle.setAttribute( 'aria-pressed', hidden ? 'true' : 'false' );
		}
	}

	function chosenRows() {
		var entries = stranded.slice();

		Array.prototype.forEach.call(
			picker.querySelectorAll( 'tr.is-hidden[data-lstab-pick-index]' ),
			function ( row ) {
				entries.push( {
					index: row.getAttribute( 'data-lstab-pick-index' ) || '0',
					name: row.getAttribute( 'data-lstab-pick-name' ) || '',
					sig: row.getAttribute( 'data-lstab-pick-sig' ) || '',
					label: row.getAttribute( 'data-lstab-pick-label' ) || '',
					line: row.getAttribute( 'data-lstab-pick-line' ) || '',
					stranded: false
				} );
			}
		);

		return entries;
	}

	function syncRows() {
		var entries = chosenRows();

		fields.innerHTML = '';
		chips.innerHTML = '';

		entries.forEach( function ( entry, position ) {
			[ 'index', 'name', 'sig', 'label' ].forEach( function ( part ) {
				var field = document.createElement( 'input' );
				field.type = 'hidden';
				field.name = 'hidden_rows[' + position + '][' + part + ']';
				field.value = entry[ part ];
				fields.appendChild( field );
			} );

			var chip = document.createElement( 'li' );
			chip.className = 'lstab-picker-chip' + ( entry.stranded ? ' is-orphan' : '' );

			var line = document.createElement( 'strong' );
			line.className = 'lstab-picker-chip-line';
			line.textContent = entry.line;
			chip.appendChild( line );

			var label = document.createElement( 'span' );
			label.textContent = entry.label || entry.name;
			chip.appendChild( label );

			if ( entry.stranded ) {
				var note = document.createElement( 'em' );
				note.className = 'lstab-picker-chip-note';
				note.textContent = i18n.notThereNow || 'not on that line now';
				chip.appendChild( note );
			}

			var remove = document.createElement( 'button' );
			remove.type = 'button';
			remove.className = 'lstab-picker-chip-remove';
			remove.setAttribute( 'aria-label', ( i18n.showRowAgain || 'Show this row again' ) + ': ' + ( entry.label || entry.name ) );
			remove.textContent = '×';
			remove.addEventListener( 'click', function () {
				stranded = stranded.filter( function ( other ) {
					return other.index !== entry.index;
				} );
				setRow( entry.index, false );
			} );
			chip.appendChild( remove );

			chips.appendChild( chip );
		} );

		if ( empty ) {
			empty.hidden = entries.length > 0;
		}
	}

	function setRow( index, hidden ) {
		var row = picker.querySelector( 'tr[data-lstab-pick-index="' + index + '"]' );

		if ( row ) {
			row.classList.toggle( 'is-hidden', hidden );

			var toggle = row.querySelector( 'button[data-lstab-pick-row]' );
			if ( toggle ) {
				toggle.setAttribute( 'aria-pressed', hidden ? 'true' : 'false' );
			}
		}

		syncRows();
	}

	picker.addEventListener( 'click', function ( event ) {
		var chevron = event.target.closest( '.lstab-picker-detail' );

		if ( chevron && ! chevron.disabled ) {
			var detailIndex = chevron.getAttribute( 'data-lstab-pick-detail' );
			var field = detailField( detailIndex );
			var wanted = 'true' !== chevron.getAttribute( 'aria-pressed' );

			if ( field ) {
				field.value = wanted ? '1' : '0';
			}

			paintDetail( detailIndex, wanted );
			paintState( detailIndex, false );
			return;
		}

		var toggle = event.target.closest( '.lstab-picker-toggle' );
		if ( ! toggle || toggle.disabled ) {
			return;
		}

		var column = toggle.getAttribute( 'data-lstab-pick-column' );

		if ( null !== column ) {
			var field = columnField( column );
			var hidden = 'true' !== toggle.getAttribute( 'aria-pressed' );

			if ( field ) {
				field.value = hidden ? '1' : '0';
			}

			if ( hidden ) {
				var detailToo = detailField( column );

				if ( detailToo ) {
					detailToo.value = '0';
				}

				paintDetail( column, false );
			}

			var chevronButton = picker.querySelector( 'button[data-lstab-pick-detail="' + column + '"]' );
			if ( chevronButton ) {
				chevronButton.disabled = hidden;
			}

			paintColumn( column, hidden );
			paintState( column, hidden );
			return;
		}

		var index = toggle.getAttribute( 'data-lstab-pick-row' );
		if ( null !== index ) {
			setRow( index, 'true' !== toggle.getAttribute( 'aria-pressed' ) );
		}
	} );

	syncRows();
}() );
