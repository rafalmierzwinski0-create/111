<?php

defined( 'ABSPATH' ) || exit;

$lstab_can_add = LSTAB_Limits::can_add_source();

$lstab_own = array_filter(
	$sources,
	static function ( $candidate ) {
		return ! LSTAB_Example::is_example( $candidate );
	}
);

$lstab_add_button = $lstab_can_add
	? sprintf(
		'<a href="%s" class="lstab-btn">%s%s</a>',
		esc_url( admin_url( 'admin.php?page=' . LSTAB_Admin::EDIT_SLUG ) ),
		LSTAB_Icons::icon( 'plus' ),
		esc_html__( 'Add a sheet', 'live-sheets-table' )
	)
	: '';
?>
<div class="wrap lstab-admin">
	<?php LSTAB_Admin::render_masthead( LSTAB_Admin::masthead_summary( $sources ), $lstab_add_button ); ?>

	<?php LSTAB_Admin::render_tabs( LSTAB_Admin::SOURCES_SLUG ); ?>

	<?php LSTAB_Admin::print_cron_notice(); ?>
	<?php LSTAB_Admin::print_notice(); ?>

	<?php if ( ! $lstab_own ) : ?>
		<?php require LSTAB_PATH . 'includes/views/welcome.php'; ?>
	<?php endif; ?>

	<?php if ( $sources ) : ?>
		<div class="lstab-src-list">
			<?php
			$lstab_intervals = LSTAB_Limits::intervals();

			foreach ( $sources as $lstab_source ) :
				$lstab_state     = LSTAB_Admin::card_state( $lstab_source );
				$lstab_columns   = LSTAB_Admin::column_names( $lstab_source );
				$lstab_places    = LSTAB_Usage::places( (int) $lstab_source['id'] );
				$lstab_history   = LSTAB_Storage::history( $lstab_source );
				$lstab_shortcode = '[sheet_table id="' . (int) $lstab_source['id'] . '"]';
				$lstab_is_sample = LSTAB_Example::is_example( $lstab_source );
				?>
				<article class="lstab-src lstab-src--<?php echo esc_attr( $lstab_state['tone'] ); ?>">
					<div class="lstab-src-body">
						<div class="lstab-src-top">
							<h2 class="lstab-src-title">
								<?php echo LSTAB_Icons::icon( 'grid' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
								<?php echo esc_html( $lstab_source['title'] ); ?>
							</h2>

							<span class="lstab-src-actions">
								<a class="lstab-mini lstab-mini--strong" href="
									<?php
									echo esc_url(
										add_query_arg(
											array(
												'page'   => LSTAB_Admin::EDIT_SLUG,
												'source' => $lstab_source['id'],
											),
											admin_url( 'admin.php' )
										)
									);
									?>
								"><?php echo LSTAB_Icons::icon( 'pencil' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?><?php esc_html_e( 'Edit', 'live-sheets-table' ); ?></a>

								<?php if ( ! $lstab_is_sample ) : ?>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="lstab-inline-form">
										<?php wp_nonce_field( 'lstab_refresh_source' ); ?>
										<input type="hidden" name="action" value="lstab_refresh_source">
										<input type="hidden" name="source_id" value="<?php echo esc_attr( (string) $lstab_source['id'] ); ?>">
										<button type="submit" class="lstab-mini">
											<?php echo LSTAB_Icons::icon( 'refresh' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
											<?php esc_html_e( 'Refresh', 'live-sheets-table' ); ?>
										</button>
									</form>
								<?php endif; ?>
							</span>
						</div>

						<div class="lstab-src-facts">
							<span class="lstab-state lstab-state--<?php echo esc_attr( $lstab_state['tone'] ); ?>">
								<?php echo LSTAB_Icons::icon( $lstab_state['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
								<?php echo esc_html( $lstab_state['text'] ); ?>
							</span>

							<span class="lstab-fact">
								<?php echo LSTAB_Icons::icon( 'columns' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
								<?php
								printf(
									/* translators: 1: row count, 2: column count. */
									esc_html__( '%1$s rows × %2$s columns', 'live-sheets-table' ),
									'<b>' . esc_html( number_format_i18n( $lstab_source['row_count'] ) ) . '</b>',
									'<b>' . esc_html( number_format_i18n( $lstab_source['col_count'] ) ) . '</b>'
								);
								?>
							</span>

							<?php if ( ! $lstab_is_sample ) : ?>
								<span class="lstab-fact">
									<?php echo LSTAB_Icons::icon( 'clock' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
									<?php
									echo esc_html(
										isset( $lstab_intervals[ $lstab_source['sync_interval'] ] )
											? $lstab_intervals[ $lstab_source['sync_interval'] ]
											: sprintf(
												/* translators: %s: duration. */
												__( 'Every %s', 'live-sheets-table' ),
												LSTAB_Locale::span( 0, $lstab_source['sync_interval'] )
											)
									);
									?>
								</span>
							<?php endif; ?>

							<?php if ( $lstab_source['tab_name'] ) : ?>
								<span class="lstab-fact">
									<?php echo LSTAB_Icons::icon( 'layers' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
									<?php
									printf(
										/* translators: %s: the name of the tab inside the spreadsheet. */
										esc_html__( 'Tab: %s', 'live-sheets-table' ),
										'<b>' . esc_html( $lstab_source['tab_name'] ) . '</b>'
									);
									?>
								</span>
							<?php endif; ?>

							<?php if ( count( $lstab_history ) > 1 ) : ?>
								<?php
								$lstab_failed = count( array_filter( $lstab_history, static function ( $lstab_mark ) {
									return 'error' === $lstab_mark;
								} ) );
								?>
								<span class="lstab-fact lstab-fact--checks">
									<?php echo LSTAB_Icons::icon( 'refresh' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
									<?php esc_html_e( 'Last checks', 'live-sheets-table' ); ?>

									<span class="lstab-spark" aria-hidden="true">
										<?php foreach ( $lstab_history as $lstab_mark ) : ?>
											<i class="lstab-bar lstab-bar--<?php echo esc_attr( $lstab_mark ); ?>"></i>
										<?php endforeach; ?>
									</span>

									<?php if ( $lstab_failed ) : ?>
										<b class="lstab-spark-failed">
											<?php
											printf(
												/* translators: %s: how many of the last few checks failed. */
												esc_html( _n( '%s failed', '%s failed', $lstab_failed, 'live-sheets-table' ) ),
												esc_html( number_format_i18n( $lstab_failed ) )
											);
											?>
										</b>
									<?php endif; ?>

									<span class="screen-reader-text">
										<?php
										printf(
											/* translators: 1: how many checks are shown, 2: how many of them failed. */
											esc_html( _n(
												'The last %1$s check, oldest first. %2$s of them failed.',
												'The last %1$s checks, oldest first. %2$s of them failed.',
												count( $lstab_history ),
												'live-sheets-table'
											) ),
											esc_html( number_format_i18n( count( $lstab_history ) ) ),
											esc_html( number_format_i18n( $lstab_failed ) )
										);
										?>
									</span>
								</span>
							<?php endif; ?>
						</div>

						<?php if ( $lstab_state['note'] ) : ?>
							<p class="lstab-src-note"><?php echo esc_html( $lstab_state['note'] ); ?></p>
						<?php endif; ?>

						<?php if ( ! empty( $lstab_source['last_ragged'] ) ) : ?>
							<p class="lstab-src-note lstab-src-note--warn">
								<?php echo LSTAB_Icons::icon( 'alert' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
								<?php echo esc_html( LSTAB_Admin::ragged_summary( $lstab_source['last_ragged'] ) ); ?>
							</p>
						<?php endif; ?>

						<?php if ( LSTAB_Paging::should_offer( $lstab_source ) ) : ?>
							<div class="lstab-src-offer">
								<p class="lstab-src-offer-say">
									<?php echo LSTAB_Icons::icon( 'pages' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
									<span>
										<?php
										printf(
											/* translators: 1: number of rows, 2: rows a page would hold. */
											esc_html__( 'This sheet has grown to %1$s rows. Shall it be shown %2$s at a time? Visitors get page buttons, the page loads quicker, and searching and sorting still cover every row.', 'live-sheets-table' ),
											esc_html( number_format_i18n( (int) $lstab_source['row_count'] ) ),
											esc_html( number_format_i18n( LSTAB_Paging::auto_per_page() ) )
										);
										?>
									</span>
								</p>

								<span class="lstab-src-offer-do">
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="lstab-inline-form">
										<?php wp_nonce_field( 'lstab_page_source' ); ?>
										<input type="hidden" name="action" value="lstab_page_source">
										<input type="hidden" name="source_id" value="<?php echo esc_attr( (string) $lstab_source['id'] ); ?>">
										<button type="submit" class="lstab-mini lstab-mini--strong">
											<?php
											printf(
												/* translators: %s: rows a page would hold. */
												esc_html__( 'Yes, %s at a time', 'live-sheets-table' ),
												esc_html( number_format_i18n( LSTAB_Paging::auto_per_page() ) )
											);
											?>
										</button>
									</form>

									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="lstab-inline-form">
										<?php wp_nonce_field( 'lstab_keep_one_page' ); ?>
										<input type="hidden" name="action" value="lstab_keep_one_page">
										<input type="hidden" name="source_id" value="<?php echo esc_attr( (string) $lstab_source['id'] ); ?>">
										<button type="submit" class="lstab-mini">
											<?php esc_html_e( 'No, keep one long table', 'live-sheets-table' ); ?>
										</button>
									</form>
								</span>
							</div>
						<?php endif; ?>

						<?php if ( $lstab_columns['names'] ) : ?>
							<div class="lstab-colchips">
								<?php foreach ( $lstab_columns['names'] as $lstab_name ) : ?>
									<span class="lstab-colchip"><?php echo esc_html( $lstab_name ); ?></span>
								<?php endforeach; ?>
								<?php if ( $lstab_columns['extra'] > 0 ) : ?>
									<span class="lstab-colchip lstab-colchip--more">
										+<?php echo esc_html( number_format_i18n( $lstab_columns['extra'] ) ); ?>
										<span class="screen-reader-text">
											<?php
											printf(
												/* translators: %s: how many further columns the sheet has. */
												esc_html( _n( '%s more column', '%s more columns', (int) $lstab_columns['extra'], 'live-sheets-table' ) ),
												esc_html( number_format_i18n( $lstab_columns['extra'] ) )
											);
											?>
										</span>
									</span>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<p class="lstab-used">
							<?php echo LSTAB_Icons::icon( 'doc' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
							<?php if ( $lstab_places ) : ?>
								<?php esc_html_e( 'Used on', 'live-sheets-table' ); ?>
								<?php
								$lstab_links = array();
								foreach ( array_slice( $lstab_places, 0, 3 ) as $lstab_place ) {
									$lstab_links[] = $lstab_place['url']
										? '<a href="' . esc_url( $lstab_place['url'] ) . '">' . esc_html( $lstab_place['title'] ) . '</a>'
										: esc_html( $lstab_place['title'] );
								}

								echo wp_kses( implode( ', ', $lstab_links ), array( 'a' => array( 'href' => array() ) ) );

								if ( count( $lstab_places ) > 3 ) {
									echo esc_html(
										sprintf(
											/* translators: %s: number of further pages. */
											__( ' and %s more', 'live-sheets-table' ),
											number_format_i18n( count( $lstab_places ) - 3 )
										)
									);
								}
								?>
							<?php else : ?>
								<span class="lstab-used-none"><?php esc_html_e( 'Not on any page yet — safe to delete', 'live-sheets-table' ); ?></span>
							<?php endif; ?>
						</p>

						<?php
						$lstab_purge = LSTAB_Cache::last( (int) $lstab_source['id'] );
						?>
						<?php if ( $lstab_purge && ! empty( $lstab_purge['time'] ) && 'pages' === $lstab_purge['scope'] ) : ?>
							<p class="lstab-used lstab-purged">
								<?php echo LSTAB_Icons::icon( 'bolt' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
								<?php
								printf(
									esc_html(
										/* translators: 1: number of pages, 2: human readable duration, e.g. "5 minutes". */
										_n(
											'Page cache cleared on %1$s page, %2$s ago',
											'Page cache cleared on %1$s pages, %2$s ago',
											(int) $lstab_purge['posts'],
											'live-sheets-table'
										)
									),
									esc_html( number_format_i18n( (int) $lstab_purge['posts'] ) ),
									esc_html( LSTAB_Locale::span( (int) $lstab_purge['time'] ) )
								);
								?>
							</p>
						<?php endif; ?>

						<div class="lstab-src-use">
							<code class="lstab-shortcode"><?php echo esc_html( $lstab_shortcode ); ?></code>

							<button type="button"
								class="lstab-copy"
								data-lstab-copy="<?php echo esc_attr( $lstab_shortcode ); ?>">
								<?php echo LSTAB_Icons::icon( 'copy' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
								<span class="lstab-copy-label"><?php esc_html_e( 'Copy', 'live-sheets-table' ); ?></span>
							</button>

							<span class="lstab-src-spare">
								<?php if ( ! $lstab_is_sample ) : ?>
									<a class="lstab-quiet" target="_blank" rel="noopener noreferrer"
										href="<?php echo esc_url( LSTAB_Url::edit_url( $lstab_source['sheet_id'], $lstab_source['gid'], $lstab_source['sheet_kind'] ) ); ?>">
										<?php echo LSTAB_Icons::icon( 'external' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
										<?php esc_html_e( 'In Google', 'live-sheets-table' ); ?>
									</a>
								<?php endif; ?>

								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="lstab-inline-form"
									onsubmit="return window.confirm( <?php echo esc_js( wp_json_encode( __( 'Delete this sheet source? Tables using it will stop rendering.', 'live-sheets-table' ) ) ); ?> );">
									<?php wp_nonce_field( 'lstab_delete_source' ); ?>
									<input type="hidden" name="action" value="lstab_delete_source">
									<input type="hidden" name="source_id" value="<?php echo esc_attr( (string) $lstab_source['id'] ); ?>">
									<button type="submit" class="lstab-quiet lstab-quiet--danger">
										<?php echo LSTAB_Icons::icon( 'trash' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
										<?php esc_html_e( 'Delete', 'live-sheets-table' ); ?>
									</button>
								</form>
							</span>
						</div>
					</div>
				</article>
			<?php endforeach; ?>
		</div>

		<?php if ( ! LSTAB_Example::exists() && count( $sources ) < 3 ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="lstab-example-offer">
				<input type="hidden" name="action" value="lstab_add_example">
				<?php wp_nonce_field( 'lstab_add_example' ); ?>
				<?php echo LSTAB_Icons::icon( 'play' ); // phpcs:ignore WordPress.Security.EscapeOutput -- Static SVG. ?>
				<span><?php esc_html_e( 'Add the built-in example price list to try the settings out. It never contacts Google.', 'live-sheets-table' ); ?></span>
				<button type="submit" class="lstab-mini lstab-mini--strong"><?php esc_html_e( 'Add the example', 'live-sheets-table' ); ?></button>
			</form>
		<?php endif; ?>

		<?php if ( ! $lstab_can_add ) : ?>
			<div class="lstab-upsell">
				<h3><?php esc_html_e( 'Need more than one sheet?', 'live-sheets-table' ); ?></h3>
				<p>
					<?php esc_html_e( 'Pro adds unlimited sources, one-minute syncing, colour rules, filtered views, extra styles and private sheets.', 'live-sheets-table' ); ?>
				</p>
				<a class="lstab-btn lstab-btn--quiet" href="<?php echo esc_url( LSTAB_Limits::upgrade_url() ); ?>" target="_blank" rel="noopener noreferrer">
					<?php esc_html_e( 'Compare Free and Pro', 'live-sheets-table' ); ?>
				</a>
			</div>
		<?php endif; ?>
	<?php endif; ?>
</div>
