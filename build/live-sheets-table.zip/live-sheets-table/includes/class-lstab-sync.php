<?php
/**
 * Sync orchestration.
 *
 * @package LiveSheetsTable
 */

defined( 'ABSPATH' ) || exit;

/**
 * Runs a fetch for one source and records the outcome.
 */
class LSTAB_Sync {

	/**
	 * How long one visitor is made to wait for a sheet, in seconds.
	 *
	 * Short on purpose. A stale table is a small problem; a page that hangs
	 * because Google is slow is the fault this plugin exists to avoid, and it
	 * would be a strange way to acquire it.
	 */
	const VIEW_TIMEOUT = 4;

	/**
	 * How long one attempt keeps others from trying, in seconds.
	 */
	const VIEW_LOCK = 30;

	/**
	 * Bring a sheet up to date while someone is looking at it.
	 *
	 * WordPress has no clock of its own: WP-Cron runs on visits, and it runs
	 * *after* the page has been sent. So the visitor whose arrival triggers a
	 * sync is the one who does not benefit from it, and on a quiet site nobody
	 * triggers one at all. This closes that gap for sources that ask for it —
	 * the refresh happens before the page is drawn, so the person who waited
	 * for it is the person who sees it.
	 *
	 * Three things keep it from becoming the problem it solves. Only one
	 * request fetches at a time, so ten simultaneous visitors do not become ten
	 * requests to Google. The wait is capped, and a sheet that does not answer
	 * in time leaves the stored copy on the page. And a source that has just
	 * failed is not retried until its interval has passed, so a broken sheet
	 * costs one slow page rather than every page.
	 *
	 * @param array<string,mixed> $source Source row.
	 * @return array<string,mixed> The source, refreshed if it was worth it.
	 */
	public static function refresh_for_view( $source ) {
		if ( empty( $source['refresh_on_view'] ) || empty( $source['id'] ) ) {
			return $source;
		}

		// Cron already has its own turn at this, and nobody is waiting there.
		if ( wp_doing_cron() ) {
			return $source;
		}

		// Never while another request is already doing it.
		$lock = 'lstab_view_refresh_' . (int) $source['id'];

		if ( get_transient( $lock ) ) {
			return $source;
		}

		$interval = max( 60, (int) $source['sync_interval'] );
		$attempt  = empty( $source['last_attempt_gmt'] ) ? 0 : strtotime( $source['last_attempt_gmt'] . ' UTC' );

		// Measured from the last attempt rather than the last success, so a
		// sheet that keeps failing is not fetched again on every page view.
		if ( $attempt && ( time() - $attempt ) < $interval ) {
			return $source;
		}

		set_transient( $lock, 1, self::VIEW_LOCK );

		$shorten = function ( $args ) {
			$args['timeout'] = self::VIEW_TIMEOUT;

			return $args;
		};

		add_filter( 'lstab_fetch_args', $shorten, 99 );
		$result = self::run( (int) $source['id'] );
		remove_filter( 'lstab_fetch_args', $shorten, 99 );

		delete_transient( $lock );

		if ( is_wp_error( $result ) ) {
			// The stored copy is still on the page, which is the whole promise.
			return $source;
		}

		$fresh = LSTAB_Storage::get( (int) $source['id'] );

		return $fresh ? $fresh : $source;
	}

	/**
	 * Sync a single source.
	 *
	 * On failure the stored snapshot is deliberately left alone, so the front
	 * end keeps serving the last good copy instead of an empty or broken table.
	 *
	 * @param int $id Source ID.
	 * @return true|WP_Error
	 */
	public static function run( $id ) {
		$source = LSTAB_Storage::get( $id );

		if ( ! $source ) {
			return new WP_Error( 'lstab_unknown_source', __( 'That sheet source no longer exists.', 'live-sheets-table' ) );
		}

		/**
		 * Fires before a source is synced.
		 *
		 * @param array $source Source row.
		 */
		do_action( 'lstab_before_sync', $source );

		$table = LSTAB_Fetcher::fetch_table(
			$source['sheet_id'],
			$source['gid'],
			$source['sheet_kind'],
			(bool) $source['first_row_header']
		);

		if ( is_wp_error( $table ) ) {
			LSTAB_Storage::record_failure( $id, $table->get_error_message() );

			/**
			 * Fires when a sync attempt fails.
			 *
			 * @param array    $source Source row.
			 * @param WP_Error $table  The failure.
			 */
			do_action( 'lstab_sync_failed', $source, $table );

			return $table;
		}

		/**
		 * Filters the parsed table before it is stored.
		 *
		 * @param array $table  Parsed table {headers, rows}.
		 * @param array $source Source row.
		 */
		$table = (array) apply_filters( 'lstab_parsed_table', $table, $source );

		// Remember which heading each position actually carried, so a column
		// inserted in the sheet can be reported rather than silently shifting
		// every configured label one place along.
		$columns = LSTAB_Columns::reconcile(
			isset( $source['columns_config'] ) ? $source['columns_config'] : array(),
			isset( $table['headers'] ) ? $table['headers'] : array()
		);

		LSTAB_Storage::update( $id, array( 'columns_config' => $columns ) );
		LSTAB_Storage::record_success( $id, $table );

		/**
		 * Fires after a source syncs successfully.
		 *
		 * @param array $source Source row.
		 * @param array $table  Parsed table.
		 */
		do_action( 'lstab_after_sync', $source, $table );

		return true;
	}

	/**
	 * Sync every source whose interval has elapsed.
	 *
	 * @param bool $force Ignore the interval and sync everything.
	 * @return array<int,string> Map of source ID to 'ok' or an error message.
	 */
	public static function run_due( $force = false ) {
		$results = array();

		foreach ( LSTAB_Storage::get_all() as $source ) {
			if ( ! $force && ! self::is_due( $source ) ) {
				continue;
			}

			$result                    = self::run( $source['id'] );
			$results[ $source['id'] ] = is_wp_error( $result ) ? $result->get_error_message() : 'ok';
		}

		return $results;
	}

	/**
	 * Whether a source is due for a refresh.
	 *
	 * @param array<string,mixed> $source Source row.
	 * @return bool
	 */
	public static function is_due( $source ) {
		if ( empty( $source['last_attempt_gmt'] ) ) {
			return true;
		}

		$last = strtotime( $source['last_attempt_gmt'] . ' UTC' );
		if ( ! $last ) {
			return true;
		}

		$interval = max( 60, (int) $source['sync_interval'] );

		// Allow a small amount of slack so a cron tick that fires a few seconds
		// early does not push the refresh a whole interval into the future.
		return ( time() - $last ) >= ( $interval - 30 );
	}
}
