<?php

defined( 'ABSPATH' ) || exit;

class LSTAB_Elementor_Widget extends \Elementor\Widget_Base {
	public function get_name() {
		return 'lstab-sheet-table';
	}

	public function get_title() {
		return __( 'Google Sheets Table', 'live-sheets-table' );
	}

	public function get_icon() {
		return 'eicon-table';
	}

	public function get_categories() {
		return array( 'live-sheets-table' );
	}

	public function get_keywords() {
		return array( 'google', 'sheets', 'table', 'spreadsheet', 'csv' );
	}

	public function get_style_depends() {
		return array( 'lstab-table' );
	}

	public function get_script_depends() {
		return array( 'lstab-table' );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'lstab_source_section',
			array( 'label' => __( 'Sheet', 'live-sheets-table' ) )
		);

		$this->add_control(
			'source_id',
			array(
				'label'   => __( 'Table', 'live-sheets-table' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => LSTAB_Elementor::source_options(),
				'default' => 0,
			)
		);

		$this->add_control(
			'source_hint',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					/* translators: %s: link to the plugin's own screen. */
					__( 'Tables are added and updated in %s.', 'live-sheets-table' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=' . LSTAB_Admin::SOURCES_SLUG ) ) . '" target="_blank">' . esc_html__( 'Live Sheets Table → All tables', 'live-sheets-table' ) . '</a>'
				),
				'content_classes' => 'elementor-descriptor',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'lstab_display_section',
			array( 'label' => __( 'Display', 'live-sheets-table' ) )
		);

		$this->add_control(
			'show_search',
			array(
				'label'   => __( 'Search box', 'live-sheets-table' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'show_sort',
			array(
				'label'   => __( 'Sorting by column', 'live-sheets-table' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'show_updated',
			array(
				'label'   => __( 'Show “updated … ago”', 'live-sheets-table' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => __( 'Layout', 'live-sheets-table' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'inherit',
				'options' => array(
					'inherit' => __( 'As set for the table', 'live-sheets-table' ),
					'table'   => __( 'Table with a slider', 'live-sheets-table' ),
					'auto'    => __( 'Cards when it stops fitting', 'live-sheets-table' ),
					'cards'   => __( 'Always cards', 'live-sheets-table' ),
				),
			)
		);

		$this->add_control(
			'style_preset',
			array(
				'label'   => __( 'Table style', 'live-sheets-table' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '',
				'options' => self::preset_options(),
			)
		);

		$this->add_control(
			'caption',
			array(
				'label' => __( 'Caption', 'live-sheets-table' ),
				'type'  => \Elementor\Controls_Manager::TEXT,
			)
		);

		$this->end_controls_section();

		if ( apply_filters( 'lstab_filter_supported', false ) ) {
			$this->start_controls_section(
				'lstab_rows_section',
				array( 'label' => __( 'Which rows', 'live-sheets-table' ) )
			);

			$this->add_control(
				'filter',
				array(
					'label'       => __( 'Filter', 'live-sheets-table' ),
					'type'        => \Elementor\Controls_Manager::TEXT,
					'description' => __( 'Show only the rows that match, for example: Category is Bikes. To use several conditions, join them with “and” or a comma; a row must match all of them. The words you can use are listed on the Live Sheets Table → Pro screen.', 'live-sheets-table' ),
				)
			);

			$this->end_controls_section();
		}
	}

	protected static function preset_options() {
		$options = array( '' => __( 'As set for the table', 'live-sheets-table' ) );

		foreach ( LSTAB_Styles::all() as $key => $preset ) {
			$options[ $key ] = isset( $preset['label'] ) ? $preset['label'] : $key;
		}

		return $options;
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$html = LSTAB_Renderer::render(
			array(
				'source_id' => absint( isset( $settings['source_id'] ) ? $settings['source_id'] : 0 ),
				'search'    => 'yes' === ( isset( $settings['show_search'] ) ? $settings['show_search'] : 'yes' ),
				'sort'      => 'yes' === ( isset( $settings['show_sort'] ) ? $settings['show_sort'] : 'yes' ),
				'show_meta' => 'yes' === ( isset( $settings['show_updated'] ) ? $settings['show_updated'] : 'yes' ),
				'style'     => sanitize_key( isset( $settings['style_preset'] ) ? $settings['style_preset'] : '' ),
				'layout'    => sanitize_key( isset( $settings['layout'] ) ? $settings['layout'] : 'inherit' ),
				'caption'   => sanitize_text_field( isset( $settings['caption'] ) ? $settings['caption'] : '' ),
				'filter'    => LSTAB_Shortcode::filter_text( isset( $settings['filter'] ) ? $settings['filter'] : '' ),
			)
		);

		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- The renderer escapes its own output.
	}
}
