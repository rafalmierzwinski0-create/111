<?php

defined( 'ABSPATH' ) || exit;

class LSTAB_Block {
	public function register() {
		add_action( 'init', array( $this, 'register_block' ) );
	}

	public function register_block() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		$block = register_block_type(
			LSTAB_PATH . 'blocks/sheet-table',
			array( 'render_callback' => array( $this, 'render' ) )
		);

		if ( ! $block || empty( $block->editor_script_handles ) ) {
			return;
		}

		wp_localize_script(
			$block->editor_script_handles[0],
			'lstabBlock',
			array(
				'manageUrl' => admin_url( 'admin.php?page=' . LSTAB_Admin::SOURCES_SLUG ),
				'editUrl'   => admin_url( 'admin.php?page=' . LSTAB_Admin::EDIT_SLUG . '&source=' ),
				'addUrl'    => admin_url( 'admin.php?page=' . LSTAB_Admin::EDIT_SLUG ),
				'canFilter' => (bool) apply_filters( 'lstab_filter_supported', false ),
				'canChoose' => current_user_can( LSTAB_Limits::capability() ),
				'presets'   => self::preset_options(),
			)
		);
	}

	protected static function preset_options() {
		$options = array();

		foreach ( LSTAB_Styles::all() as $slug => $preset ) {
			$options[] = array(
				'label' => (string) $preset['label'],
				'value' => (string) $slug,
			);
		}

		return $options;
	}

	public function render( $attributes ) {
		$attributes = wp_parse_args(
			(array) $attributes,
			array(
				'sourceId'    => 0,
				'showSearch'  => null,
				'showSort'    => null,
				'showUpdated' => null,
				'stylePreset' => '',
				'caption'     => '',
				'layout'      => 'inherit',
				'filter'      => '',
			)
		);

		$html = LSTAB_Renderer::render(
			array(
				'source_id' => absint( $attributes['sourceId'] ),
				'search'    => null === $attributes['showSearch'] ? null : (bool) $attributes['showSearch'],
				'sort'      => null === $attributes['showSort'] ? null : (bool) $attributes['showSort'],
				'show_meta' => null === $attributes['showUpdated'] ? null : (bool) $attributes['showUpdated'],
				'style'     => sanitize_key( (string) $attributes['stylePreset'] ),
				'caption'   => sanitize_text_field( (string) $attributes['caption'] ),
				'layout'    => sanitize_key( (string) $attributes['layout'] ),
				'filter'    => LSTAB_Shortcode::filter_text( $attributes['filter'] ),
			)
		);

		if ( '' === $html ) {
			return '';
		}

		return '<div ' . $this->wrapper_attributes() . '>' . $html . '</div>';
	}

	protected function wrapper_attributes() {
		$in_render_pipeline = class_exists( 'WP_Block_Supports' )
			&& isset( WP_Block_Supports::$block_to_render['blockName'] );

		if ( $in_render_pipeline && function_exists( 'get_block_wrapper_attributes' ) ) {
			return get_block_wrapper_attributes( array( 'class' => 'lstab-block' ) );
		}

		return 'class="wp-block-tabliko-sheet-table lstab-block"';
	}
}
