<?php

defined( 'ABSPATH' ) || exit;

$lstab_own = array_filter(
	$sources,
	static function ( $candidate ) {
		return ! LSTAB_Example::is_example( $candidate );
	}
);

$lstab_add_button = sprintf(
	'<a href="%s" class="lstab-btn">%s%s</a>',
	esc_url( admin_url( 'admin.php?page=' . LSTAB_Admin::EDIT_SLUG ) ),
	LSTAB_Icons::icon( 'plus' ),
	esc_html__( 'Add a table', 'tabliko' )
);
?>
<div class="wrap lstab-admin">
	<?php LSTAB_Admin::render_masthead( LSTAB_Admin::masthead_summary( $sources ), $lstab_add_button ); ?>

	<?php LSTAB_Admin::render_tabs( LSTAB_Admin::SOURCES_SLUG ); ?>

	<?php LSTAB_Admin::print_notice(); ?>

	<?php if ( ! $lstab_own ) : ?>
		<?php require LSTAB_PATH . 'includes/views/welcome.php'; ?>
	<?php endif; ?>

	<?php if ( $sources ) : ?>
		<div class="lstab-src-list">
			<?php
			foreach ( $sources as $lstab_source ) :
				$lstab_state     = LSTAB_Admin::card_state( $lstab_source );
				$lstab_columns   = LSTAB_Admin::column_names( $lstab_source );
				$lstab_places    = LSTAB_Usage::places( (int) $lstab_source['id'] );
				$lstab_history   = LSTAB_Storage::history( $lstab_source );
				$lstab_shortcode = '[tabliko id="' . (int) $lstab_source['id'] . '"]';
				$lstab_is_sample = LSTAB_Example::is_example( $lstab_source );
				?>
				<article class="lstab-src lstab-src--<?php echo esc_attr( $lstab_state['tone'] ); ?>">
					<div class="lstab-src-body">
						<div class="lstab-src-top">
							<h2 class="lstab-src-title">
								<?php echo wp_kses( LSTAB_Icons::icon( 'grid' ), LSTAB_Icons::allowed() ); ?>
								<?php echo esc_html( $lstab_source['title'] ); ?>
							</h2>

							<span class="lstab-src-actions">
								<a class="lstab-mini lstab-mini--strong" href="
									<?php
									echo esc_url(
										add_query_arg(
											array(
												'page'   => LSTAB_Admin::EDIT_SLUG,
												'source' => $lstab_source['id'],
											),
											admin_url( 'admin.php' )
										)
									);
									?>
								"><?php echo wp_kses( LSTAB_Icons::icon( 'pencil' ), LSTAB_Icons::allowed() ); ?><?php esc_html_e( 'Edit', 'tabliko' ); ?></a>

								<?php if ( ! $lstab_is_sample ) : ?>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="lstab-inline-form">
										<?php wp_nonce_field( 'lstab_refresh_source' ); ?>
										<input type="hidden" name="action" value="lstab_refresh_source">
										<input type="hidden" name="source_id" value="<?php echo esc_attr( (string) $lstab_source['id'] ); ?>">
										<button type="submit" class="lstab-mini">
											<?php echo wp_kses( LSTAB_Icons::icon( 'refresh' ), LSTAB_Icons::allowed() ); ?>
											<?php esc_html_e( 'Refresh', 'tabliko' ); ?>
										</button>
									</form>
								<?php endif; ?>
							</span>
						</div>

						<div class="lstab-src-facts">
							<span class="lstab-state lstab-state--<?php echo esc_attr( $lstab_state['tone'] ); ?>">
								<?php echo wp_kses( LSTAB_Icons::icon( $lstab_state['icon'] ), LSTAB_Icons::allowed() ); ?>
								<?php echo esc_html( $lstab_state['text'] ); ?>
							</span>

							<span class="lstab-fact">
								<?php echo wp_kses( LSTAB_Icons::icon( 'columns' ), LSTAB_Icons::allowed() ); ?>
								<?php
								printf(
									/* translators: 1: row count, 2: column count. */
									esc_html__( '%1$s rows × %2$s columns', 'tabliko' ),
									'<b>' . esc_html( number_format_i18n( $lstab_source['row_count'] ) ) . '</b>',
									'<b>' . esc_html( number_format_i18n( $lstab_source['col_count'] ) ) . '</b>'
								);
								?>
							</span>

							<?php if ( ! $lstab_is_sample ) : ?>
								<span class="lstab-fact">
									<?php echo wp_kses( LSTAB_Icons::icon( 'clock' ), LSTAB_Icons::allowed() ); ?>
									<?php
									echo esc_html( LSTAB_Limits::label( $lstab_source['sync_interval'] ) );
									?>
								</span>
							<?php endif; ?>

							<?php if ( $lstab_source['tab_name'] ) : ?>
								<span class="lstab-fact">
									<?php echo wp_kses( LSTAB_Icons::icon( 'layers' ), LSTAB_Icons::allowed() ); ?>
									<?php
									printf(
										/* translators: %s: the name of the tab inside the spreadsheet. */
										esc_html__( 'Tab: %s', 'tabliko' ),
										'<b>' . esc_html( $lstab_source['tab_name'] ) . '</b>'
									);
									?>
								</span>
							<?php endif; ?>

							<?php if ( count( $lstab_history ) > 1 ) : ?>
								<?php
								$lstab_failed = count( array_filter( $lstab_history, static function ( $lstab_mark ) {
									return 'error' === $lstab_mark;
								} ) );
								?>
								<span class="lstab-fact lstab-fact--checks">
									<?php echo wp_kses( LSTAB_Icons::icon( 'refresh' ), LSTAB_Icons::allowed() ); ?>
									<?php esc_html_e( 'Last checks', 'tabliko' ); ?>

									<span class="lstab-spark" aria-hidden="true">
										<?php foreach ( $lstab_history as $lstab_mark ) : ?>
											<i class="lstab-bar lstab-bar--<?php echo esc_attr( $lstab_mark ); ?>"></i>
										<?php endforeach; ?>
									</span>

									<?php if ( $lstab_failed ) : ?>
										<b class="lstab-spark-failed">
											<?php
											printf(
												/* translators: %s: how many of the last few checks failed. */
												esc_html( _n( '%s failed', '%s failed', $lstab_failed, 'tabliko' ) ),
												esc_html( number_format_i18n( $lstab_failed ) )
											);
											?>
										</b>
									<?php endif; ?>

									<span class="screen-reader-text">
										<?php
										printf(
											/* translators: 1: how many checks are shown, 2: how many of them failed. */
											esc_html( _n(
												'The last %1$s check, oldest first. %2$s of them failed.',
												'The last %1$s checks, oldest first. %2$s of them failed.',
												count( $lstab_history ),
												'tabliko'
											) ),
											esc_html( number_format_i18n( count( $lstab_history ) ) ),
											esc_html( number_format_i18n( $lstab_failed ) )
										);
										?>
									</span>
								</span>
							<?php endif; ?>
						</div>

						<?php if ( $lstab_state['note'] ) : ?>
							<p class="lstab-src-note"><?php echo esc_html( $lstab_state['note'] ); ?></p>
						<?php endif; ?>

						<?php if ( ! empty( $lstab_source['last_ragged'] ) ) : ?>
							<p class="lstab-src-note lstab-src-note--warn">
								<?php echo wp_kses( LSTAB_Icons::icon( 'alert' ), LSTAB_Icons::allowed() ); ?>
								<?php echo esc_html( LSTAB_Admin::ragged_summary( $lstab_source['last_ragged'] ) ); ?>
							</p>
						<?php endif; ?>

						<?php if ( LSTAB_Paging::should_offer( $lstab_source ) ) : ?>
							<div class="lstab-src-offer">
								<p class="lstab-src-offer-say">
									<?php echo wp_kses( LSTAB_Icons::icon( 'pages' ), LSTAB_Icons::allowed() ); ?>
									<span>
										<?php
										printf(
											/* translators: 1: number of rows, 2: rows a page would hold. */
											esc_html__( 'This sheet has grown to %1$s rows. Show it %2$s rows per page? The page loads faster, visitors get page buttons, and searching and sorting still cover every row.', 'tabliko' ),
											esc_html( number_format_i18n( (int) $lstab_source['row_count'] ) ),
											esc_html( number_format_i18n( LSTAB_Paging::auto_per_page() ) )
										);
										?>
									</span>
								</p>

								<span class="lstab-src-offer-do">
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="lstab-inline-form">
										<?php wp_nonce_field( 'lstab_page_source' ); ?>
										<input type="hidden" name="action" value="lstab_page_source">
										<input type="hidden" name="source_id" value="<?php echo esc_attr( (string) $lstab_source['id'] ); ?>">
										<button type="submit" class="lstab-mini lstab-mini--strong">
											<?php
											printf(
												/* translators: %s: rows a page would hold. */
												esc_html__( 'Yes, %s at a time', 'tabliko' ),
												esc_html( number_format_i18n( LSTAB_Paging::auto_per_page() ) )
											);
											?>
										</button>
									</form>

									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="lstab-inline-form">
										<?php wp_nonce_field( 'lstab_keep_one_page' ); ?>
										<input type="hidden" name="action" value="lstab_keep_one_page">
										<input type="hidden" name="source_id" value="<?php echo esc_attr( (string) $lstab_source['id'] ); ?>">
										<button type="submit" class="lstab-mini">
											<?php esc_html_e( 'No, keep one long table', 'tabliko' ); ?>
										</button>
									</form>
								</span>
							</div>
						<?php endif; ?>

						<?php if ( $lstab_columns['names'] ) : ?>
							<div class="lstab-colchips">
								<?php foreach ( $lstab_columns['names'] as $lstab_name ) : ?>
									<span class="lstab-colchip"><?php echo esc_html( $lstab_name ); ?></span>
								<?php endforeach; ?>
								<?php if ( $lstab_columns['extra'] > 0 ) : ?>
									<span class="lstab-colchip lstab-colchip--more">
										+<?php echo esc_html( number_format_i18n( $lstab_columns['extra'] ) ); ?>
										<span class="screen-reader-text">
											<?php
											printf(
												/* translators: %s: how many further columns the sheet has. */
												esc_html( _n( '%s more column', '%s more columns', (int) $lstab_columns['extra'], 'tabliko' ) ),
												esc_html( number_format_i18n( $lstab_columns['extra'] ) )
											);
											?>
										</span>
									</span>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<p class="lstab-used">
							<?php echo wp_kses( LSTAB_Icons::icon( 'doc' ), LSTAB_Icons::allowed() ); ?>
							<?php if ( $lstab_places ) : ?>
								<?php esc_html_e( 'Used on', 'tabliko' ); ?>
								<?php
								$lstab_links = array();
								foreach ( array_slice( $lstab_places, 0, 3 ) as $lstab_place ) {
									$lstab_links[] = $lstab_place['url']
										? '<a href="' . esc_url( $lstab_place['url'] ) . '">' . esc_html( $lstab_place['title'] ) . '</a>'
										: esc_html( $lstab_place['title'] );
								}

								echo wp_kses( implode( ', ', $lstab_links ), array( 'a' => array( 'href' => array() ) ) );

								if ( count( $lstab_places ) > 3 ) {
									echo esc_html(
										sprintf(
											/* translators: %s: number of further pages. */
											__( ' and %s more', 'tabliko' ),
											number_format_i18n( count( $lstab_places ) - 3 )
										)
									);
								}
								?>
							<?php else : ?>
								<span class="lstab-used-none"><?php esc_html_e( 'Not on any page yet — safe to delete', 'tabliko' ); ?></span>
							<?php endif; ?>
						</p>

						<?php
						$lstab_purge = LSTAB_Cache::last( (int) $lstab_source['id'] );
						?>
						<?php if ( $lstab_purge && ! empty( $lstab_purge['time'] ) && 'pages' === $lstab_purge['scope'] ) : ?>
							<p class="lstab-used lstab-purged">
								<?php echo wp_kses( LSTAB_Icons::icon( 'bolt' ), LSTAB_Icons::allowed() ); ?>
								<?php
								printf(
									esc_html(
										/* translators: 1: number of pages, 2: human readable duration, e.g. "5 minutes". */
										_n(
											'Page cache cleared on %1$s page, %2$s ago',
											'Page cache cleared on %1$s pages, %2$s ago',
											(int) $lstab_purge['posts'],
											'tabliko'
										)
									),
									esc_html( number_format_i18n( (int) $lstab_purge['posts'] ) ),
									esc_html( LSTAB_Locale::span( (int) $lstab_purge['time'] ) )
								);
								?>
							</p>
						<?php endif; ?>

						<div class="lstab-src-use">
							<code class="lstab-shortcode"><?php echo esc_html( $lstab_shortcode ); ?></code>

							<button type="button"
								class="lstab-copy"
								data-lstab-copy="<?php echo esc_attr( $lstab_shortcode ); ?>">
								<?php echo wp_kses( LSTAB_Icons::icon( 'copy' ), LSTAB_Icons::allowed() ); ?>
								<span class="lstab-copy-label"><?php esc_html_e( 'Copy', 'tabliko' ); ?></span>
							</button>

							<span class="lstab-src-spare">
								<?php if ( ! $lstab_is_sample ) : ?>
									<a class="lstab-quiet" target="_blank" rel="noopener noreferrer"
										href="<?php echo esc_url( LSTAB_Url::edit_url( $lstab_source['sheet_id'], $lstab_source['gid'], $lstab_source['sheet_kind'] ) ); ?>">
										<?php echo wp_kses( LSTAB_Icons::icon( 'external' ), LSTAB_Icons::allowed() ); ?>
										<?php esc_html_e( 'In Google', 'tabliko' ); ?>
									</a>
								<?php endif; ?>

								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="lstab-inline-form"
									onsubmit="return window.confirm( <?php echo esc_js( wp_json_encode( __( 'Delete this table? Pages that show it will show nothing in its place. Your sheet in Google is not touched.', 'tabliko' ) ) ); ?> );">
									<?php wp_nonce_field( 'lstab_delete_source' ); ?>
									<input type="hidden" name="action" value="lstab_delete_source">
									<input type="hidden" name="source_id" value="<?php echo esc_attr( (string) $lstab_source['id'] ); ?>">
									<button type="submit" class="lstab-quiet lstab-quiet--danger">
										<?php echo wp_kses( LSTAB_Icons::icon( 'trash' ), LSTAB_Icons::allowed() ); ?>
										<?php esc_html_e( 'Delete', 'tabliko' ); ?>
									</button>
								</form>
							</span>
						</div>
					</div>
				</article>
			<?php endforeach; ?>
		</div>

		<?php if ( ! LSTAB_Example::exists() && count( $sources ) < 3 ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="lstab-example-offer">
				<input type="hidden" name="action" value="lstab_add_example">
				<?php wp_nonce_field( 'lstab_add_example' ); ?>
				<?php echo wp_kses( LSTAB_Icons::icon( 'play' ), LSTAB_Icons::allowed() ); ?>
				<span><?php esc_html_e( 'Add the example price list that comes with the plugin and try the settings on it. It never contacts Google.', 'tabliko' ); ?></span>
				<button type="submit" class="lstab-mini lstab-mini--strong"><?php esc_html_e( 'Add the example', 'tabliko' ); ?></button>
			</form>
		<?php endif; ?>

	<?php endif; ?>
</div>
