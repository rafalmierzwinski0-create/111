<?php

defined( 'ABSPATH' ) || exit;

class LSTAB_Rest {
	const NAMESPACE_V1 = 'tabliko/v1';

	public function register() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			self::NAMESPACE_V1,
			'/preview',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'preview' ),
				'permission_callback' => array( $this, 'can_manage' ),
				'args'                => array(
					'url'            => array(
						'type'     => 'string',
						'required' => true,
					),
					'gid'            => array(
						'type'    => 'string',
						'default' => '',
					),
					'firstRowHeader' => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'style'          => array(
						'type'    => 'string',
						'default' => '',
					),
					'layout'         => array(
						'type'    => 'string',
						'default' => 'table',
					),
					'sticky'         => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'stickyHead'     => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'search'         => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'sort'           => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'meta'           => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'linkCells'      => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'perPage'        => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'columns'        => array(
						'type'    => 'array',
						'default' => array(),
					),
					'sourceId'       => array(
						'type'    => 'integer',
						'default' => 0,
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/sources',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'list_sources' ),
				'permission_callback' => array( $this, 'can_edit_posts' ),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/redraw',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'redraw' ),
				'permission_callback' => array( $this, 'can_manage' ),
				'args'                => array(
					'sourceId' => array(
						'type'     => 'integer',
						'required' => true,
					),
					'style'    => array(
						'type'    => 'string',
						'default' => '',
					),
					'layout'   => array(
						'type'    => 'string',
						'default' => 'table',
					),
					'sticky'   => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'stickyHead' => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'search'     => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'sort'       => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'meta'       => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'linkCells'  => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'perPage'    => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'columns'  => array(
						'type'    => 'array',
						'default' => array(),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/sources/(?P<id>\d+)/refresh',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'refresh' ),
				'permission_callback' => array( $this, 'can_manage' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);
	}

	public function can_manage() {
		if ( current_user_can( LSTAB_Limits::capability() ) ) {
			return true;
		}

		return new WP_Error(
			'lstab_forbidden',
			__( 'You are not allowed to manage tables.', 'tabliko' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	public function can_edit_posts() {
		if ( current_user_can( 'edit_posts' ) ) {
			return true;
		}

		return new WP_Error(
			'lstab_forbidden',
			__( 'You are not allowed to see the list of tables.', 'tabliko' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	public function redraw( $request ) {
		$source_id = absint( $request->get_param( 'sourceId' ) );
		$source    = $source_id ? LSTAB_Storage::get( $source_id ) : null;

		if ( ! $source ) {
			return new WP_Error(
				'lstab_unknown_source',
				__( 'That table has been deleted.', 'tabliko' ),
				array( 'status' => 404 )
			);
		}

		if ( empty( $source['data']['headers'] ) && empty( $source['data']['rows'] ) ) {
			return new WP_Error(
				'lstab_nothing_stored',
				__( 'The sheet has not been read yet, so there is nothing to show. Choose “Load preview” first.', 'tabliko' ),
				array( 'status' => 409 )
			);
		}

		$rows    = (array) $source['data']['rows'];
		$preview = array_slice( $rows, 0, 25 );

		do_action( 'lstab_preview_request', $request, $source_id );
		self::navigate( $request, $source_id );

		return rest_ensure_response(
			array(
				'rowCount'  => count( $rows ),
				'colCount'  => count( (array) $source['data']['headers'] ),
				'truncated' => count( $rows ) > count( $preview ) && $request->get_param( 'perPage' ) <= 0,
				'html'      => LSTAB_Renderer::render_preview(
					array(
						'headers' => (array) $source['data']['headers'],
						'rows'    => $rows,
					),
					array(
						'style'       => LSTAB_Styles::sanitize( (string) $request->get_param( 'style' ) ),
						'layout'      => (string) $request->get_param( 'layout' ),
						'sticky'      => (bool) $request->get_param( 'sticky' ),
						'sticky_head' => (bool) $request->get_param( 'stickyHead' ),
						'search'      => false !== $request->get_param( 'search' ),
						'sort'        => false !== $request->get_param( 'sort' ),
						'show_meta'   => false !== $request->get_param( 'meta' ),
						'last_success_gmt' => isset( $source['last_success_gmt'] ) ? $source['last_success_gmt'] : null,
						'link_cells'  => false !== $request->get_param( 'linkCells' ),
						'per_page'    => max( 0, (int) $request->get_param( 'perPage' ) ),
						'limit'       => $request->get_param( 'perPage' ) > 0 ? 0 : 25,
						'source_id'   => $source_id,
						'columns'    => LSTAB_Columns::sanitize( (array) $request->get_param( 'columns' ) ),
						'style_vars' => isset( $source['style_vars'] ) ? $source['style_vars'] : array(),
					)
				),
			)
		);
	}

	protected static function navigate( $request, $source_id ) {
		$nav = $request->get_param( 'nav' );

		if ( ! is_array( $nav ) || $source_id <= 0 ) {
			return;
		}

		$carried = array();

		foreach ( array( 'q', 'page', 'sort', 'dir' ) as $name ) {
			$key = LSTAB_Paging::arg( $source_id, $name );

			if ( isset( $nav[ $key ] ) && is_scalar( $nav[ $key ] ) ) {
				$carried[ $key ] = sanitize_text_field( (string) $nav[ $key ] );
				$_GET[ $key ]    = $carried[ $key ];
			}
		}

		$_SERVER['REQUEST_URI'] = add_query_arg( array_map( 'rawurlencode', $carried ), wp_parse_url( admin_url( 'admin.php' ), PHP_URL_PATH ) );
	}

	public function preview( $request ) {
		$reference = LSTAB_Url::parse( (string) $request->get_param( 'url' ) );

		if ( is_wp_error( $reference ) ) {
			return new WP_Error(
				$reference->get_error_code(),
				$reference->get_error_message(),
				array( 'status' => 400 )
			);
		}

		$gid = (string) $request->get_param( 'gid' );
		if ( '' !== $gid ) {
			$reference['gid'] = LSTAB_Url::sanitize_gid( $gid );
		}

		$first_row_header = (bool) $request->get_param( 'firstRowHeader' );

		$csv = LSTAB_Fetcher::fetch_csv(
			$reference['sheet_id'],
			$reference['gid'],
			$reference['sheet_kind']
		);

		if ( is_wp_error( $csv ) ) {
			return new WP_Error(
				$csv->get_error_code(),
				$csv->get_error_message(),
				array( 'status' => 502 )
			);
		}

		$table = LSTAB_CSV_Parser::parse( $csv, $first_row_header );

		if ( is_wp_error( $table ) ) {
			return new WP_Error(
				$table->get_error_code(),
				$table->get_error_message(),
				array( 'status' => 502 )
			);
		}

		$tabs = LSTAB_Fetcher::fetch_tabs( $reference['sheet_id'], $reference['sheet_kind'] );
		if ( is_wp_error( $tabs ) ) {
			$tabs = array();
		}

		$rows    = $table['rows'];
		$preview = array_slice( $rows, 0, 25 );

		do_action( 'lstab_preview_request', $request, absint( $request->get_param( 'sourceId' ) ) );
		self::navigate( $request, absint( $request->get_param( 'sourceId' ) ) );

		return rest_ensure_response(
			array(
				'sheetId'   => $reference['sheet_id'],
				'sheetKind' => $reference['sheet_kind'],
				'gid'       => $reference['gid'],
				'tabs'      => $tabs,
				'headers'   => $table['headers'],
				'rows'      => $preview,
				'rowCount'  => count( $rows ),
				'colCount'  => count( $table['headers'] ),
				'truncated' => count( $rows ) > count( $preview ),
				'raw'       => self::sample( $csv ),
				'rawBytes'  => strlen( $csv ),
				'ragged'    => isset( $table['ragged'] ) ? $table['ragged'] : null,
				'html'      => LSTAB_Renderer::render_preview(
					array(
						'headers' => $table['headers'],
						'rows'    => $rows,
					),
					array(
						'style'       => LSTAB_Styles::sanitize( (string) $request->get_param( 'style' ) ),
						'layout'      => (string) $request->get_param( 'layout' ),
						'sticky'      => (bool) $request->get_param( 'sticky' ),
						'sticky_head' => (bool) $request->get_param( 'stickyHead' ),
						'search'      => false !== $request->get_param( 'search' ),
						'sort'        => false !== $request->get_param( 'sort' ),
						'show_meta'   => false !== $request->get_param( 'meta' ),
						'last_success_gmt' => gmdate( 'Y-m-d H:i:s' ),
						'link_cells'  => false !== $request->get_param( 'linkCells' ),
						'per_page'    => absint( $request->get_param( 'sourceId' ) ) ? max( 0, (int) $request->get_param( 'perPage' ) ) : 0,
						'limit'       => absint( $request->get_param( 'sourceId' ) ) && $request->get_param( 'perPage' ) > 0 ? 0 : 25,
						'source_id'   => absint( $request->get_param( 'sourceId' ) ),
						'columns'   => LSTAB_Columns::sanitize( (array) $request->get_param( 'columns' ) ),
					)
				),
			)
		);
	}

	protected static function sample( $csv ) {
		$limit = 4000;

		if ( strlen( $csv ) <= $limit ) {
			return $csv;
		}

		$cut  = substr( $csv, 0, $limit );
		$last = strrpos( $cut, "\n" );

		return ( false === $last ? $cut : substr( $cut, 0, $last ) ) . "\n…";
	}

	public function list_sources() {
		$sources = array();

		foreach ( LSTAB_Storage::get_all() as $source ) {
			$sources[] = array(
				'id'          => $source['id'],
				'title'       => $source['title'],
				'rowCount'    => $source['row_count'],
				'colCount'    => $source['col_count'],
				'lastStatus'  => $source['last_status'],
				'lastSuccess' => $source['last_success_gmt'],
			);
		}

		return rest_ensure_response( $sources );
	}

	public function refresh( $request ) {
		$id     = absint( $request->get_param( 'id' ) );
		$result = LSTAB_Sync::run( $id );

		if ( is_wp_error( $result ) ) {
			return new WP_Error(
				$result->get_error_code(),
				$result->get_error_message(),
				array( 'status' => 502 )
			);
		}

		$source = LSTAB_Storage::get( $id );

		return rest_ensure_response(
			array(
				'success'     => true,
				'rowCount'    => $source ? $source['row_count'] : 0,
				'lastSuccess' => $source ? $source['last_success_gmt'] : null,
			)
		);
	}
}
